import getBase, { add, multiply } from './02-19-modules.mjs';

console.log(add(4));
console.log(getBase());
